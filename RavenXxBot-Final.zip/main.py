import telebot
from config import BOT_TOKEN, ADMIN_ID

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['start'])
def start_cmd(message):
    bot.reply_to(message, "🤖 RavenXxBot Online!
Use /help to view commands.")

@bot.message_handler(commands=['help'])
def help_cmd(message):
    bot.reply_to(message, "/bin [BIN]
/sk [key]
/ccn [card]
/weather [city]
/mail [email]
...")

bot.polling()